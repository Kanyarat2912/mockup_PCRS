<?php
date_default_timezone_set("Asia/Bangkok");
// mysql_connect("sdm148020","root","root123456") or die(mysql_error());
// mysql_select_db("pcrdb");
	include("connectpcr.php");
	include("connectdbmc.php");
	// include("auto_anp.php");
/*	
echo $_POST["number_ap"]."<br/>";
echo $_POST["create_date_ap"]."<br/>"; 
echo $_POST["issue_ap"]."<br/>"; 
echo $_POST["section_ap"]."<br/>";
echo $_POST["company_ap"]."<br/>";
echo $_POST["additionitem_ap"]."<br/>";
echo $_POST["title_pcr"]."<br/>";
echo $_POST["change_type"]."<br/>";
echo $_POST["rank_ap"]."<br/>";
echo $_POST["Custo_sub_ap"]."<br/>";
echo $_POST["plan_re_aq"]."<br/>";
echo $_POST["product_ap"]."<br/>";
echo $_POST["part_name_ap"]."<br/>";
echo $_POST["change_point_ap"]."<br/>";
echo $_POST["Output_ap"]."<br/>";
echo $_POST["customer_ap"]."<br/>";
echo $_POST["line_ap"]."<br/>";
echo $_POST["process_ap"]."<br/>";
*/
date_default_timezone_set('asia/bangkok');
$number_pcr = $_POST["pcr_number"]; // pcr number
$create_date = $_POST["create_date"];
$part_number =  $_POST["part_number"];	
$file_plan =  $_POST["img"];
//imprements
$pcr_plan_sub_plan = $_POST["pcr_plan_sub_plan"];
$pcr_plan_sub_actual =  $_POST["pcr_plan_sub_actual"];
$plan_review_plan = $_POST["plan_review_plan"];
$plan_review_actual =  $_POST["plan_review_actual"];
$pro_preparation_plan = $_POST["pro_preparation_plan"];
$pro_preparation_actual = $_POST["pro_preparation_actual"]; 
$product_evaluation_plan = $_POST["product_evaluation_plan"];
$product_evaluation_result = $_POST["product_evaluation_result"];
$revise_doc_stadart_plan = $_POST["revise_doc_stadart_plan"];
$revise_doc_stadart_result = $_POST["revise_doc_stadart_result"];
$six_report_plan = $_POST["six_report_plan"];
$six_report_result = $_POST["six_report_result"];
$pcr_result_sum_plan = $_POST["pcr_result_sum_plan"];
$pcr_result_sum_result = $_POST["pcr_result_sum_result"];
$product_start_date_plan = $_POST["product_start_date_plan"];
$product_start_date_result = $_POST["product_start_date_result"];

// Data attachments
$check_PFMEA =  $_POST["check_PFMEA"];
$check_qa_network =  $_POST["check_qa_network"];
$check_control_plan =  $_POST["check_qa_network"];
$standardize =  $_POST["standardize"];
$machine_sprci =  $_POST["machine_sprci"];
$daily_check =  $_POST["daily_check"];
$other =  $_POST["other"];


//Approve of department
$section_ap = $_POST["group_app_department"]; // section annual plan
$product_ap =  $_POST["product_ap"];
$rank_ap =  $_POST["rank_ap"];
$delete_ap = 1;

$issue_ap =  $_POST["issue_ap"];  // person issue annual plan 
$customer_ap =  $_POST["customer_ap"];
$company_ap =  $_POST["company_ap"];





$sql = "INSERT INTO pcr_form (fm_pcr_number,fm_pcr_leadtime,fm_part_number,fm_state_app,fm_phase,fm_create_date,fm_anp_id,,fm_qap_id,fm_bkd_id,fm_bkd_id,fm_att_id,fm_usr_emp_code,) VALUES ('$number_ap','$part_name_ap','$title_pcr','$custo_sub_ap','$line_ap','$output_ap','$process_ap','$additionitem_ap','$plan_re_aq',
									  '$change_type','0','$change_point_ap','$section_ap','$product_ap','$rank_ap','$delete_ap','$issue_ap','$customer_ap','$company_ap')";

//include("update_auto_anp.php");

	
	//$anp = $_POST["number_ap"];
	$sql2 = "UPDATE pcr_auto_gen SET seq = '".$num_pls."' WHERE num = 1 ";
	
	$query2 = mysqli_query($conn,$sql2);


if(mysqli_query($conn, $sql)){
    echo "<script language=\"JavaScript\">";
						echo "alert('Issue Annual Plan Success .');";
						echo "</script>";
						// echo '<meta http-equiv=refresh content=0;URL=../INT/IN0021.php>';
} else{
						echo "<script language=\"JavaScript\">";
						echo "alert('Can not Issue Annual Plan Please check value.');";
						echo "</script>";
						// echo '<meta http-equiv=refresh content=0;URL=../INT/IN0020.php>';
}
 
// Close connection
mysqli_close($conn);

?>
