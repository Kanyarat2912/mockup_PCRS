
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
