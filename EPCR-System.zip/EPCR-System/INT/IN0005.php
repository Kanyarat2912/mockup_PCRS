	
<!DOCTYPE html>
<html lang="en">
	<head>
	 <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.js"></script>
	 <script src="path-to/node_modules/bootstrap-table/dist/bootstrap-table.min.js"></script>
   <!--<link rel="stylesheet" href="path-to/node_modules/bootstrap-table/dist/bootstrap-table.min.css"/>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->

  
	</head>
  <body>
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_user.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
            
			<li class="nav-item sidebar-actions">
              <span class="nav-link">  
			  <a class="nav-link">
                </a>
              </span>
            </li>
			<div><b>QAP Approval</b></div><br>
				<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i>
				</button>			
                     <!----------------------------------- table report ----------------------------------------->
									<div class="col-12 grid-margin stretch-card">
                <div class="card">
				
                  <div class="card-body">
                    <h4 class="card-title">Process Change Report</h4>
                    <p class="card-description"> Table of Process </p>
                    <form class="forms-sample">
                    <div class="table-responsive">
                      <table id="example" class="table table-hover table-bordered dt-responsive nowrap" style="width:100%">
                         <thead class="thead-dark">
                          <tr>
							<th><center> No </center></th>
							<th><center> Date </center></th>
                            <th><center> Product name </center></th>
                            <th><center> Title</center> </th>
                            <th><center> Rank </center></th>
                            <th> <center>Customer submission </center></th>
							<th> <center>Status </center> </th>	
                            <th> <center>PIC </center></th>
							<th><center> PCR type </center></th>					
							<th><center> Action </center> </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
						  <td> <center>1</center></td>
						  <td>01/07/2020</td>
                            <td> HP5S</td>
                            <td> New G4S Body pre washing machine </td>
                            <td>
                              C1
                            </td>
                            <td> All</td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>						
							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';" ><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo">
								<i class ="mdi mdi-checkbox-multiple-marked-circle"></i>
							</button>			
							
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							
							</center>
							</td>
                          </tr>
                          <tr>
						  <td> <center>2 </center></td>
						  <td>05/05/2020</td>
                            <td>HP3 </td>
                            <td> Improvement process flow </td>
                            <td>
                              C3
                            </td>
							
                            <td> All </td>
							<td><label class="badge badge-gradient-warning">ON PLAN</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>
							
							<td>
							<center>
								<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i>
							</button>			
                          
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
						
							</center>
							</td>
                          </tr>
                          <tr>
						  <td>  <center>3 </center></td>
						  <td>01/03/2020</td>
                            <td>INJ</td>
                            <td> Tool cost down by change </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>

							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i>
							</button>			
                        
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							</center>
							</td>
							
                          </tr>
                          <tr>
						  <td> <center> 4  </center></td>
						  	<td>01/02/2019</td>
                            <td>Pump </td>
                            <td> Mirror insert for OD-EF turning </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-danger">REJECTED</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>

							
							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i>
							</button>		
                           
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							
							
							
							
							</center>
							
							  </div>
							
							</td>
                          </tr>
                        </tbody>.
                      </table>
                 </div>
				   </form>
                  </div>
                </div>
						
						
						
					 <!------------------------------------- table report ---------------------------------------->

            </div>
	</div>

	</div>	
	</div>
	   
	   
	   
	  
  </body>
  
</html>


<!--------------------------------------- Modal QAP approval ----------------------------------------->
						<div id="approveModal" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
								<div class="modal-content">
						
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center"></h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
										<div class="card">
											<h3 class="page-title-icon bg-gradient-primary " style="background-color:#b66dff;text-align:center">
												<b class="text-white">QAP Approval</b> 
											</h3>
											<div class="card-body">
												  <form class="card-header">
												  <div><b>Planning review meeting</b></div><br>
													  <div>
														<label>Chairman</label>
														<div>
														  <input type="text" class="form-control" />
														</div>
													  </div>
													  &nbsp;
														<div class="form-group">
														<label for="exampleTextarea1">Comment</label>
														<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
													  </div>          
													</form>
													<div><b>6 Step meeting</b></div><br>
													<!--- test-->
													<div class="row">
														<div class="col-md-6">
														  <div class="form-group">
														  <div class=>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">  
																Part Examination
																</label>
															</div>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">
																Process Examination
															  </label>
																
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input" >  
																Shipment Review
																</label>
															</div>
															
														  </div>
														</div>
														<div class="col-md-6">
														   <div class="form-group">
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input"> 
																Process Explanationd
																</label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">
																Total  Review
																</label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input"> 
																QA Meeting
																</label>
															</div>
															
														  </div>
														</div>
													  </div>
													  <div><b>1 Step no meeting</b></div><br>
													<div class="row">
														<div class="col-md-6">
													   <div class="form-group">
														<div class="form-check">
														  <label class="form-check-label">
															<input type="checkbox" class="form-check-input"> 
															QA Report
															</label>
														</div>
													  </div>
													</div>
												  </div>
												<!-- test-->
											</div>		
										</div>
									</form>
								 
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-primary btn-fw" >Submit</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">Cancel</button>
								  </div>
								  </div>
								</div>
								</div>
								</div>