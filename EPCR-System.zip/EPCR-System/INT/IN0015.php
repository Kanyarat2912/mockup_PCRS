<!DOCTYPE html>
<html lang="en">
<style>
.dot {
  height: 80px;
  width: 80px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  text-align: center;
}
.center{
	position: absolute;
	top: 30%;
	left: 50%;
	
	transform: translate(-50%, -50%);	
}
.background{
  background-image: url("../assets/images/faces/superman.svg");
  background-color: #cccccc;
}
hr {
    display: block;
    height: 1px;
    border: 0;
	border-bottom: 10px solid #000; /* whichever color you prefer */
    margin: 1em 0;
    padding: 0;
}

.icon {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  width: 80px;
  height: 60px;
  cursor: pointer;
}
.arrow::after, .arrow::before {
  content: '';
  position: absolute;
  width: 60%;
  height: 10px;
  right: -8px;
  background-color: #28a745;
}

.arrow::after {
  top: -12px;
  transform: rotate(45deg);
}

.arrow::before {
  top: 12px;
  box-shadow: 0 3px 5px rgba(0, 0, 0, .2);
  transform: rotate(-45deg);
}

.arrow {
  position: absolute;
  top: 80px;
  width: 100%;
  height: 10px;
  background-color: #28a745;
  box-shadow: 0 3px 5px rgba(0, 0, 0, .2);
  animation: arrow 700ms linear infinite;
}
.arrow-short{
  position: absolute;
  top: 80px;
  width: 30%;
  height: 10px;
  background-color: #28a745;
  box-shadow: 0 3px 5px rgba(0, 0, 0, .2);
  animation: arrow 700ms linear infinite;
}
.arrow-vertical_plan{
  position: absolute;
  top: 116px;
  right:205px;
  width: 10px;
  height: 200px;
  background-color: #28a745;
  box-shadow: 0 3px 5px rgba(0, 0, 0, .2);
  animation: arrow 700ms linear infinite;
}
.arrow-vertical_result{
  position: absolute;
  top: 116px;
  right:205px;
  width: 10px;
  height: 185px;
  background-color: #28a745;

  animation: arrow 700ms linear infinite;
}
.arrow-qa-plan{
  position: absolute;
  top: 40px;
  width: 100%;
  height: 10px;
  background-color: #28a745;
 
  animation: arrow 700ms linear infinite;
	
}
.arrow-qa-result{
  position: absolute;
  top: 40px;
  width: 107%;
  height: 10px;
  background-color: #28a745;
  box-shadow: 0 3px 5px rgba(0, 0, 0, .2);
  animation: arrow 700ms linear infinite;
	
}
/* ******************************************************* */

</style>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End Plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
	  <?php
	include("header_user.php")?>
		
	  
	  
	  
<div class="main-panel">
		
   <div class="content-wrapper">
	 <div class="col-12">
			<br><br>
			
        <div class="card">
	
            <div class="card-body">
				<h4 class="card-title" style="text-align: left;"><b>Status Plan</b></h4>
					<br>
					
							
					<div class="row">
                        <div class="col-md-12">
                          <div class="form-group row">
                             <div class="col-sm-4"> 
								<div class = "row">
									<div class="col-md-12" style="text-align:left;">
										<div class="col-sm-7" > 
											<p style="text-align:left;"><b>Creator</b></p>
										</div>	
											<img class="dot" src="../assets/images/faces/deadpool.svg" alt="profile" style="background-color: #008080;" />
											<img class="arrow" />											
											<!--<img src="../assets/images/faces/right-arrow.svg" alt="profile" style=" width: 40%; height: 40%; " />	-->
									</div>
								</div>
							 </div>
							<!--********************************************* ลูกศร ******************************************** -->
					
							<!--********************************************* ลูกศร ******************************************** -->
                             <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<div class="col-sm-12"  style="text-align: left;"> 
											<p style="text-align:left;"><b>DEPT</b></p>
										</div>
										<img class="dot" src="../assets/images/faces/superman.svg" alt="profile" style="background-color: #008080;" />
										<img class="arrow" />	
									</div>
								</div>
							 </div>
							<!--********************************************* ลูกศร ******************************************** -->
							
							<!--********************************************* ลูกศร ******************************************** -->
							
							
							
							 <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<div class="col-sm-12"> 
												<p style="text-align:left;"><b>ACK</b></p>
										</div>
											<img class="dot" src="../assets/images/faces/batman.svg" alt="profile" style="background-color: #008080;"/>
											<img class="arrow-vertical_plan"/>
									</div>
								</div>
							 </div>
								
                           </div> 
                        </div>
		<!-- eye  -->
		
						<div class="col-md-12">
							<div class="form-group row">
							 <div class="col-sm-12">
								<div class = "row">
									<div class="col-md-12" style="text-align:right;">
										 <div class="col-sm-12"> 
											
										 </div>

									</div>
								</div>
                            </div>
						    </div>
                        </div>
		
		<br><br><br><br><br>
		
					<div class="col-md-12">
                        <div class="form-group row">

						    <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<img class="dot " src="../assets/images/faces/wolverine.svg" alt="profile" />
										<img class="arrow-qa-plan" />	
											<br>
											<br>
											<div class="col-sm-4">
												<p style="text-align:center;"><b>QAP</b></p> 
												
											</div>
									</div>
								</div>
                            </div>
							
							<!--********************************************* ลูกศร ******************************************** -->
					<!--   <div class="col-sm-1"> 
								<div class = "row">
									<div class="col-md-12"> 
									<hr/>													
									</div>
								</div>
							</div> -->
							<!--********************************************* ลูกศร ******************************************** -->
                            <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<img class="dot" src="../assets/images/faces/thor.svg" alt="profile" />
										<img class="arrow-qa-plan" />
											<br>
											<br>
											<div class="col-sm-4">
												<p style="text-align:center;"><b>BKD</b></p> 
											</div>
									</div>
								</div>
							</div>	
							
							<!--********************************************* ลูกศร ******************************************** -->
							
							<!--********************************************* ลูกศร ******************************************** -->
							
							 <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<img class="dot" src="../assets/images/faces/spiderman.svg" alt="profile" />
											<br>
											<br>
											<div class="col-sm-4">
												<p style="text-align:center;"><b>QAC</b></p> 
											</div>
									</div>
								</div>
							</div>	
							    
							
                        </div>
                    </div>
						
					</div>
					
					<br>
					<h4 class="card-title" style="text-align: left;"><b>Status Result</b></h4>
					<br>
					<div class="row">
                         <div class="col-md-12">
                          <div class="form-group row">
                            <div class="col-sm-4"> 
								<div class = "row">
									<div class="col-md-12">
										<div class="col-sm-7"> 
											<p style="text-align:left;"><b>Creator</b></p>
										</div>
										<img class="dot" src="../assets/images/faces/deadpool.svg" alt="profile" style="background-color: #008080;"/>	
										<img class="arrow" />		
									</div>
								</div>
							</div>
						
                            <div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12" >
										<div class="col-sm-12"> 
											<p style="text-align:left;"><b>DEPT</b></p>
										</div>
										<img class="dot" src="../assets/images/faces/superman.svg" alt="profile" style="background-color: #008080;" />
										<img class="arrow" />		
									</div>
								</div>
							</div>
							
						

							<div class="col-sm-4">
								<div class = "row">
									<div class="col-md-12">
										<div class="col-sm-12"> 
											<p style="text-align:left;"><b>ACK</b></p>
										</div>
										<img class="dot" src="../assets/images/faces/batman.svg" alt="profile" style="background-color: #008080;"/>
										<img class="arrow-vertical_result"/>
									</div>
								</div>
                            </div>
							
                          </div>
                        </div>
						
						<div class="col-md-12">
							<div class="form-group row">
							 <div class="col-sm-12">
								<div class = "row">
									<div class="col-md-12" style="text-align:right;">
										 <div class="col-sm-12"> 
											
										 </div>

									</div>
								</div>
                            </div>
						    </div>
                        </div>
						
			<br><br><br><br><br>
			
						<div class="col-md-12">
							<div class="form-group row">
							   <div class="col-sm-12">
								<div class = "row">
									<div class="col-md-7">
										<img class="dot " src="../assets/images/faces/wolverine.svg" alt="profile" />
										<img class="arrow-qa-result" />	
											<br>
											<br>
											<div class="col-sm-5">
												<p style="text-align:left;"><b>QAP</b></p> 
												
											</div>
									</div>
								</div>
                            </div>
							</div>
						</div>
						
					</div>

					
					
					<div class="row">
							 <div class="col-md-6">
								<button class="btn btn-info btn-fw" type="button"data-toggle="modal" data-target="#Approve_BKD_Modal">Submit</button>			
								<!--<button class="btn btn-danger btn-fw" type="button">Cancel</button> -->
							
							</div>
					  </div>
                </div>
		</div>
		
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!-- ************************************************************************************************************************** -->
<div class="container-fluid">
	<div class="row">
	    <div id="timeline">
			
			<div class="row timeline-movement">
				
				<div class="col-sm-6  timeline-item">
					
				</div>
			</div>



			
	
		</div>
	</div>
</div>

<!-- ********************************************************************************************************-->

		
			
   
      </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2017 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
    </div>
        <!-- main-panel ends -->
 </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
  </body>
</html>


 <div class="modal fade" id="Approve_BKD_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
						<center>
							
						</center>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
			    </div>
				<div class="modal-body">
					
							<div class="card">
								<h3 class="page-title-icon bg-gradient-primary" style=   "background-color:#b66dff;text-align: center;">
											<b class= "text-white">BKD</b> 
								 </h3>
							  <div class="card-body"> 
							  
							  
									<form class="form-sample"> <!-- Form input BKD-->
									  <div class="row">
											<label class="col-sm-5 col-form-label"><b>BKD Check</b></label>
										<div class="col-md-12">
										  <div class="form-group row">
										  <!-- <label class="col-sm-5 col-form-label">BKD Check</label>-->
											<div class="col-sm-6">
												  <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Require </label>
												  </div>
											</div>
											<div class="col-sm-6">
												  <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Not Require</label>
												  </div>
											</div>
										  </div>
										 </div>
										</div>
										  <div class="form-group">
										<label for="exampleTextarea1">More request</label>
										<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
									  </div>          
									</form>
									
								</div>
							  </div>
									
					
					
					
					
					
					
					
					
					
					
					
					
					
				</div>
				<div class="modal-footer justify-content-between">
						<button type="submit" class="btn btn-success btn-fw"  data-dismiss="modal">YES</button>
						<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
				</div>
			  </div>
		</div>
	</div>