<!DOCTYPE html>
<html lang="en">
<style>
      html, body {
      min-height: 100%;
      }
      body, div, form, input, select, textarea, label{ 
      padding: 0;
      margin: 0;
      outline: none;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px;
      color: #666;
      line-height: 22px;
      }
      
      legend {
      padding: 10px;      
      font-family: Roboto, Arial, sans-serif;
      font-size: 18px;
      color: #fff;
      background-color: #006622; 
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
      .testbox {
      display: flex;
      justify-content: center;
      align-items: center;
      height: inherit;
      padding: 20px;
      }
     
      .banner {
      position: relative;
      height: 280px;
      background-image: url("https://seeklogo.com/images/D/denso-logo-55E00551B5-seeklogo.com.png");  
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      }
      .banner::after {
      content: "";
      background-color: rgba(0, 0, 0, 0.4); 
      position: absolute;
      width: 100%;
      height: 100%;
      }
      input, select, textarea {
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      }
      input {
      width: calc(100% - 10px);
      padding: 5px;
      }
      input[type="date"] {
      padding: 4px 5px;
      }
      textarea {
      width: calc(100% - 12px);
      padding: 5px;
      }
      .item:hover p, .item:hover i, .question:hover p, .question label:hover, input:hover::placeholder {
      color:  #006622;
      }
      .item input:hover, .item select:hover, .item textarea:hover {
      border: 1px solid transparent;
      box-shadow: 0 0 3px 0  #006622;
      color: #006622;
      }
      .item {
      position: relative;
      margin: 10px 0;
      }
      
      input[type="date"]::-webkit-inner-spin-button {
      display: none;
      }
      .item i, input[type="date"]::-webkit-calendar-picker-indicator {
      position: absolute;
      font-size: 20px;
      color: #00b33c;
      }
      .item i {
      right: 1%;
      top: 30px;
      z-index: 1;
      }
      .week {
      display:flex;
      justify-content:space-between;
      }
      .columns {
      display:flex;
      justify-content:space-between;
      flex-direction:row;
      flex-wrap:wrap;
      }
      .columns div {
      width:48%;
      }
      [type="date"]::-webkit-calendar-picker-indicator {
      right: 1%;
      z-index: 2;
      opacity: 0;
      cursor: pointer;
      }
      input[type=radio], input[type=checkbox]  {
      display: none;
      }
      label.radio {
      position: relative;
      display: inline-block;
      margin: 5px 20px 15px 0;
      cursor: pointer;
      }
      .question span {
      margin-left: 30px;
      }
      .question-answer label {
      display: block;
      }
      label.radio:before {
      content: "";
      position: absolute;
      left: 0;
      width: 17px;
      height: 17px;
      border-radius: 50%;
      border: 2px solid #ccc;
      }
      input[type=radio]:checked + label:before, label.radio:hover:before {
      border: 2px solid  #b66dff;
      }
      label.radio:after {
      content: "";
      position: absolute;
      top: 6px;
      left: 5px;
      width: 10px;
      height: 4px;
      border: 3px solid  #b66dff;
      border-top: none;
      border-right: none;
      transform: rotate(-45deg);
      opacity: 0;
      }
      input[type=radio]:checked + label:after {
      opacity: 1;
      }
      .flax {
      display:flex;
      justify-content:space-around;
      }
      .btn-block {
      margin-top: 10px;
      text-align: center;
      } 
      
      @media (min-width: 568px) {
      .name-item, .city-item {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      }
      .name-item input, .name-item div {
      width: calc(50% - 20px);
      }
      .name-item div input {
      width:97%;}
      .name-item div label {
      display:block;
      padding-bottom:5px;
      }
      }
	  
	 .radio span {
     margin-left: 25px;
      }
}


    </style>
  <body>
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_user.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
		  	  
            <div class="row">
			
		  
			<li class="nav-item sidebar-actions">
              <span class="nav-link">  
			 
              </span>
            </li>
			
			<div class="col-12 grid-margin stretch-card">
            
			<div class="card">

				 <!-- <h3 class="page-title" style="background-color:#b66dff">
					<span class="page-title-icon bg-gradient-primary text-white mr-10">
					  <i class="mdi mdi-border-color" ></i>
					</span> <b class= "text-white" style="text-align: center" >Process Change Report</b> 
				  </h3> -->
				  
				  <h3 class="page-title-icon bg-gradient-primary" style="background-color:#b66dff;text-align: center;">
					 <b class= "text-white">Process Change Report</b> 
				  </h3>
				  
	<fieldset>
        <!-- <legend class="text-white"  style="background-color:#b66dff"><p style="text-align: center;"><b>Process Change Report Form</b></p></legend> -->
			
		  <div class="card-body">  	
        
<!-- Start form section 1 -->      
					<div class="card-header">
					<h4><b>Data My Creater :</b></h4>
						<div class="columns">
							<div class="item">
									<!-- have Not data input //type = hidden -->
									<input id="name" type="hidden" name="name" /> 		
							</div>
							<div class="item">
									<label for="Employee_No"><b>Create Date :</b><span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>
							
							<div class="item">
									<label for="name"><b>Department / Section :</b><span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No"><b>Registant :</b><span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>
							<div class="item">
									<label for="Employee_No"><b>No.(Automatic) :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>
						</div>
					</div>	
<!-- end form section 1 -->					
          <br>
          


<!-- Start form section 2 -->          
					<div class="card-header">
					<h4><b>Data PCR :</b></h4><br>
						<div class="row">
											<label class="col-sm-5 col-form-label">PCR type :</label>
							<div class="col-md-12">
								<div class="form-group row">
										  <!-- <label class="col-sm-5 col-form-label">BKD Check</label>-->
										  <div class="col-sm-5">
												 <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Normall 
														 </label>
												  </div>
										  
												  
											</div>
											<div class="col-sm-3">
												  <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Urgent
														 </label>
												  </div>
											</div>
				
								</div>
							</div>
						</div>									
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->				
						<div class="columns">
							<div class="item">
									<label for="name">Addition item :<span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No">Anuual Plan No :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>				
						</div>
							<div class="item">
										<label for="name">Title :<span></span></label>
										<input id="name" type="text" name="name" />
							</div>
	<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->				
						<div class="columns">	
							<div class="item">
									<label for="name">Change type :<span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No">Rank :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->				
							<div class="item">
									<label for="name">Customer submission :<span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No">Planning review :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->
							<div class="item">
									<label for="name">Product :<span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No">Part name :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>	
	<!-- /////////////////////////////////////////////////////////////////////////////////////////////////////-->
							<div class="item">
									<label for="name">Part number :<span></span></label>
									<input id="name" type="text" name="name" />
							</div>
							<div class="item">
									<label for="Employee_No">Change point :<span></span></label>
									<input id="Employee_No" type="text" name="Employee_No" required />
							</div>
						
						</div>
						
						<br>
					<label>Priority Management Category :</label>
					<div class="row">
						<div class="col-md-2">
                          <div class="form-group">
						   <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"   class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/S2-removebg.png" class="imageC2" >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"   class="form-check-input"></label>
								<img src="../assets/images/simbol/S3-removebg.png" class="imageC2" >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"  class="form-check-input" >  </label>
								<img src="../assets/images/simbol/S1-removebg.png" class="imageC2" >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                           <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"  class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/F2-removebg.png" class="imageC2" >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"   class="form-check-input"></label>
								<img src="../assets/images/simbol/F3-removebg.png" class="imageC2" >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"  class="form-check-input" >  </label>
								<img src="../assets/images/simbol/F1-removebg.png" class="imageC2" >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox" class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/E2-removebg.png" class="imageC2">
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/E3-removebg.png" class="imageC2"  >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input   type="checkbox"  class="form-check-input" >  </label>
								<img src="../assets/images/simbol/E1-removebg.png" class="imageC2"  >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox"  class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/C2-removebg.png" class="imageC2"  >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/C3-removebg.png" class="imageC2"  >
                            </div>  
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox"  class="form-check-input"></label>
								<img src="../assets/images/simbol/C4-removebg-preview.png" class="imageC2">
                            </div> 							
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox" class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/In-removebg-preview.png" class="imageC2"  >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/DK-removebg-preview.png" class="imageC2"  >
                            </div>  
														
                          </div>
                        </div>
						
                      </div>
            </div>
<!-- end form section 2 -->

<br>

<!-- Start form section 3  // Upload file-->
        
				<div class="card-header">
              <h4><b>Details of Process Change :</b></h4>
					
					<div class="form-group" >
					<br>
						<label>File upload plan</label>
						<input type="file" name="img[]" class="file-upload-default">
						<div class="input-group col-xs-12">
							  <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
							  <span class="input-group-append">
									<button class="file-upload-browse btn btn-gradient-primary" type="button" 
									style="backgroundr:#ffffff;">Upload</button>
							  </span>
						</div>
						<br>
						<br>
						<label>File upload result</label>
						<div class="input-group col-xs-12">
							  <input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
							  <span class="input-group-append">
									<button class="file-upload-browse btn btn-gradient-primary" type="button">Upload</button>
							  </span>
						</div>
					</div>
					
				
				</div>	
<!-- end form section 3 -->    

<br>

<!-- Start form section 4  // Date and time issue---->
                    
            <div class="card-header">
                     <h4><b>Implementation plan :</b></h4> <br>
						  <span>1) PCR plan submission </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>   
							<span>2) Planning review </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  
						
						<span>3) Process preparation </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  
						
						<span>4) Product / Process evaluation </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  
						
						<span>5) Revise document standard </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  
						
						<span>6) 6 step / Quality report </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  
						
						<span>7) PCR result submission </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div> 

						<span>8) Production Start Date </span>
                        <div class="columns">
                                <div class="item">     					
                                  <label for="Employee_No"><span>Plan :</span></label>
                                  <input id="Employee_No" type="date" name="Employee_No" required />      
                                </div>
                                
                                <div class="item">
                                    <label for="Employee_No"><span>Actual :</span></label>
                                    <input id="Employee_No" type="date" name="Employee_No" required />
                                </div>
                        </div>  					
                        
                    </div>	
<!-- end form section 4 -->    

<br>

<!-- Start form section 5  // Data attachments -->
                    
                    <div class="card-header">
                          <h4><b>Data attachments :</b></h4>
						
						
                    <div class="row">
						
						<div class="col-md-6">
                          <div class="form-group">
                            <div class="form-check col-md-8">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									1.PFMEA
								</label>
								<label>
									Document No.<input id="" type="text" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									2.QA Network
								</label>
								<label>
									 Document No.<input id="" type="text" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									3.Control plan ,PCC
								</label>
								<label>
									Document No.<input id="" type="text" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							<div class="form-check col-md-8">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									4.Standardize work , WI
								</label>
						
                            </div>
                          </div>
                        </div>
						
						
						<div class="col-md-6">
                          <div class="form-group">
                            <div class="form-check col-sm-8">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									5.Machine specification (Change point of machine)

								</label>
								<label>
									<input id="" type="hidden" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							
							<div class="form-check col-sm-6">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									6.Daily check sheet
								</label>
								<label>
									<input id="" type="hidden" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
							
							<div class="form-check col-sm-6">
								<label class="form-check-label">
									<input type="checkbox" class="form-check-input"> 
									7.Other
								</label>
								<label>
									<input id="" type="hidden" name=""  style = "width: 50%;"/>
								</label>
						
                            </div>
                          </div>
                        </div>
	
             </div>
	 </div>	
<!-- end form section 5 -->    

<br>

<!-- Start form section 6  // Choice Approver -->
                    
                    <div class="card-header">
                          <h3><b>Approve plan :</b></h> <br>
						<!--	<div class="columns">
                                <div class="item">                  
                                  <label for="Employee_No"><b>Prepared :</b><span></span></label>
                                  <input id="Employee_No" type="text" name="Employee_No" required />      
                                </div> 
								
                             
                        </div>-->
						<div class="row">  
							<div class="col-md-8">		<br>				
                                  <label for=""><b>Prepared :</b> 
									<input id="" type="text" name="" required style = "width: 68%;"/>  
								  </label>        
							</div>
						</div>

						
						 <h5><b  style="color: blue;"  ><u>Approve of department</u></b><h5>
						 
						<div class="row">  
							<div class="col-md-12">						
                                  <label for=""><b>Amount of  Checker :</b>
									<input id="" type="number" name=""  required style = "width: 20%;" min="0" max="5"/>  
								  </label>        
							</div>
						</div>
						<div class="columns">

                               <div class="item">                  
                                  <label for="Employee_No"><b>Prosition :</b><span></span></label>
                                  <select class="form-control " id="">
										  <option>Prosition</option>
										  <option>AM</option>
										  <option>MGR</option>
										  <option>AGM</option>
										  <option>GM</option>
										  <option>AD</option>
										  <option>ED</option>
										  <option>VP</option>
									</select>     
                                </div> 
								
								<div class="item">                  
                                  <label for="Employee_No"><b>Name :</b><span></span></label>
                                  <select class="form-control " id="">
										  <option>Name</option>
										  <option>Supatchai kamapron</option>
										  <option>Kanyarat Rodtong</option>
										  <option>Kittiya yangso</option>	  
								  </select>        
                                </div> 
                             
                        </div>
						
						<h5><b  style="color: blue;"  ><u>Acknowledge department</u></b><h5>
						<div class="columns">

                                <div class="item">                  
                                  <label for="Employee_No"><b>Prosition :</b><span></span></label>
                                  <select class="form-control " id="">
										  <option>Prosition</option>
										  <option>AM</option>
										  <option>MGR</option>
										  <option>AGM</option>
										  <option>GM</option>
										  <option>AD</option>
										  <option>ED</option>
										  <option>VP</option>
									</select>    
                                </div>
								
								<div class="item">                  
                                  <label for="Employee_No"><b>Name :</b><span></span></label>
                                 <select class="form-control " id="">
										  <option>Name</option>
										  <option>Supatchai kamapron</option>
										  <option>Kanyarat Rodtong</option>
										  <option>Kittiya yangso</option>	  
								  </select>         
                                </div> 
								
								 <div class="item">                  
                                  <label for="Employee_No"><b>Prosition :</b><span></span></label>
                                  <select class="form-control " id="">
										  <option>Prosition</option>
										  <option>AM</option>
										  <option>MGR</option>
										  <option>AGM</option>
										  <option>GM</option>
										  <option>AD</option>
										  <option>ED</option>
										  <option>VP</option>
									</select>      
                                </div>
								
								<div class="item">                  
                                  <label for="Employee_No"><b>Name :</b><span></span></label>
                                 <select class="form-control " id="">
										  <option>Name</option>
										  <option>Supatchai kamapron</option>
										  <option>Kanyarat Rodtong</option>
										  <option>Kittiya yangso</option>	  
								  </select>      
                                </div>
                             
                        </div>
						
						
						<h5><b  style="color: blue;"  ><u>Concern  department</u></b><h5>
						 
						<div class="row">  
							<div class="col-md-12">									
                                  <label for=""><b>Amount concern :</b> 
								  
									<input id="" type="number" name=""  required style = "width: 20%;" min="0" max="20"/>  
								  </label>        
							</div>
						</div>
						<div class="columns">
	
                               <div class="item">                  
                                  <label for="Employee_No"><b>Prosition :</b><span></span></label>     	
									<select class="form-control " id="">
										  <option>Prosition</option>
										  <option>AM</option>
										  <option>MGR</option>
										  <option>AGM</option>
										  <option>GM</option>
										  <option>AD</option>
										  <option>ED</option>
										  <option>VP</option>
									</select>  						  
							  </div>
								
								<div class="item">                  
                                  <label for="Employee_No"><b>Name :</b><span></span></label>
                                  <select class="form-control " id="">
										  <option>Name</option>
										  <option>Supatchai kamapron</option>
										  <option>Kanyarat Rodtong</option>
										  <option>Kittiya yangso</option>	  
								  </select>    
                                </div> 
                             
                        </div>
						<br>
								<div class="wrapper">
										
										<button type="button" class="btn btn-success btn-fw" data-toggle="modal" data-target="#Input_PCR_Modal">Success</button>		
										<button type="button" class="btn btn-dark btn-fw">Cancel</button>	
								</div>	
								
                    </div>	
<!-- end form section 6 -->    

	 
	 
						 
							</div>
						</div> 
					</div>
				</div>
			<footer class="footer">
					<div class="d-sm-flex justify-content-center justify-content-sm-between">
					  <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2017 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
					  <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
					</div>
			</footer>
			</div>
		</div>
	</div>
		
</div>	

			
	
		
		<!-- endinject -->
		<!-- Plugin js for this page -->
		<!-- End plugin js for this page -->
		<!-- inject:js -->
		<script src="../assets/js/form.js"></script>
		<script src="../assets/js/datepicker.js"></script>
		<script src="../assets/js/file-upload.js"></script>
		<script src="../assets/js/off-canvas.js"></script>
		<script src="../assets/js/hoverable-collapse.js"></script>
		<script src="../assets/js/misc.js"></script>
		<!-- endinject -->

  </body>
 <style>
	.wrapper {
		text-align: right;
	}

	.button {
		position: absolute;
		top: 50%;
	}
	.centered {
	  position: absolute;
	  top: 30%;
	  left: 50%;
	  width: 100%;
	  transform: translate(-50%, -50%);
	}
</style>
</html>



		<div class="modal fade" id="Input_PCR_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
							<center>
								<h3 class="centered">Would you like to save data?</h3>
							</center>
							<br>
							<br>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
					</div>
					<div class="modal-body">
						<form>
						</form>
					</div>
					<div class="modal-footer justify-content-between">
							<button type="submit" class="btn btn-success btn-fw"  data-dismiss="modal">YES</button>
							<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
					</div>
				</div>
			</div>
		</div>
	
	






		<div class="modal fade" id="Approve_BKD_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
							<center>
								
							</center>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
					</div>
				<div class="modal-body">
						
					<div class="card">
									<h3 class="page-title-icon bg-gradient-primary" style=   "background-color:#b66dff;text-align: center;">
												<b class= "text-white">BKD</b> 
									</h3>
						<div class="card-body">  
										<form class="form-sample"> <!-- Form input BKD-->
										  <div class="row">
												<label class="col-sm-5 col-form-label"><b>BKD Check</b></label>
											<div class="col-md-12">
											  <div class="form-group row">
											  <!-- <label class="col-sm-5 col-form-label">BKD Check</label>-->
													<div class="col-sm-6">
														  <div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Require </label>
														  </div>
													</div>
													<div class="col-sm-6">
														  <div class="form-check">
																<label class="form-check-label">
																  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Not Require</label>
														  </div>
													</div>
												 </div>
												</div>
											</div>
											  <div class="form-group">
											<label for="exampleTextarea1">More request</label>
											<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
										  </div>          
										</form>				
							</div>
						</div>	
				</div>
					<div class="modal-footer justify-content-between">
							<button type="submit" class="btn btn-success btn-fw"  data-dismiss="modal">YES</button>
							<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
					</div>
				  </div>
			</div>
		</div>    