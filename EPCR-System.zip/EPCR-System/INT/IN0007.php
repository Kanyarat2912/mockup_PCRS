	
<!DOCTYPE html>
<html lang="en">
	<head>
	<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/bootstrap-table@1.17.1/dist/bootstrap-table.min.js"></script
	 <script src="path-to/node_modules/bootstrap-table/dist/bootstrap-table.min.js"></script>
    <link rel="stylesheet" href="path-to/node_modules/bootstrap-table/dist/bootstrap-table.min.css" />
	</head>
  <body>
  <div class="container-scroller">
    <!------------------------------------------------ Header templete ------------------------------------------------>
	<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="IN0000.php"><h1><b>E-PCR</b><h1></a>
         <a class="navbar-brand brand-logo-mini" href="IN0000.php"><img src="../assets/images/gears.svg" alt="logo" style=" width: 50%; height: 50%; "/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../assets/images/settings.svg" alt="image">
                  <span class="availability-status online"></span>
                </div>
              <div class="nav-profile-text">
				<span class="menu-title"><b>Setting</b></span>
                </div> 
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="Setting_password.php">
                   <i class="mdi mdi-cached mr-2 text-success" href="IN0000.php"></i> Change Password
				 </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout mr-2 text-primary"></i> Signout 
				</a>
              </div>
            </li> 
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
    </nav>
  
  <!------------------------------------------------ Header templete ------------------------------------------------>
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_user.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
            
				
	
               
		

              </div>
            </div>
	</div>

	</div>	
	   
  </body>
</html>