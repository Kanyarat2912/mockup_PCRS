<!DOCTYPE html>
<html lang="en">
	
  <body>
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_QAP.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
            
			<li class="nav-item sidebar-actions">
              <span class="nav-link">  
			  <a class="nav-link" href="IN0001.php">
                </a>
              </span>
            </li>
			
			<div class="col-12 grid-margin stretch-card">
                <div class="card">
				
                  <div class="card-body">
                    <h4 class="card-title">Process Change Report</h4>
                    <p class="card-description"> Table of Process </p>
                    <form class="forms-sample">
                    <div class="table-responsive">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                         <thead class="thead-dark">
                          <tr>
							<th><center> No </center></th>
							<th><center> Date </center></th>
                            <th><center> Product name </center></th>
                            <th><center> Title</center> </th>
                            <th><center> Rank </center></th>
                            <th> <center>Customer submission </center></th>
							<th> <center>Status </center> </th>	
                            <th> <center>PIC </center></th>
							<th><center> PCR type </center></th>					
							<th><center> Action </center> </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
						  <td> <center>1</center></td>
						  <td>01/07/2020</td>
                            <td> HP5S</td>
                            <td> New G4S Body pre washing machine </td>
                            <td>
                              C1
                            </td>
                            <td> All</td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>						
							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';" ><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>			
                           <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog" role="document">
								<div class="modal-content">
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center">Would you like to approve?</h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
									  <div class="form-group">
										<textarea class="form-control" id="approveTextarea1" rows="6"></textarea>
									  </div>
									</form>
								  </div>
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-success btn-fw" >YES</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
								  </div>
								  </div>
								</div>
								</div>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							
							</center>
							</td>
                          </tr>
                          <tr>
						  <td> <center>2 </center></td>
						  <td>05/05/2020</td>
                            <td>HP3 </td>
                            <td> Improvement process flow </td>
                            <td>
                              C3
                            </td>
							
                            <td> All </td>
							<td><label class="badge badge-gradient-warning">ON PLAN</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>
							
							<td>
							<center>
								<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>			
                           <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog" role="document">
								<div class="modal-content">
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center">Would you like to approve?</h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
									  <div class="form-group">
										<textarea class="form-control" id="approveTextarea1" rows="6"></textarea>
									  </div>
									</form>
								  </div>
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-success btn-fw" >YES</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
								  </div>
								  </div>
								</div>
								</div>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
						
							</center>
							</td>
                          </tr>
                          <tr>
						  <td>  <center>3 </center></td>
						  <td>01/03/2020</td>
                            <td>INJ</td>
                            <td> Tool cost down by change </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>

							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>			
                           <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog" role="document">
								<div class="modal-content">
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center">Would you like to approve?</h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
									  <div class="form-group">
										<textarea class="form-control" id="approveTextarea1" rows="6"></textarea>
									  </div>
									</form>
								  </div>
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-success btn-fw" >YES</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
								  </div>
								  </div>
								</div>
								</div>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							</center>
							</td>
							
                          </tr>
                          <tr>
						  <td> <center> 4  </center></td>
						  	<td>01/02/2019</td>
                            <td>Pump </td>
                            <td> Mirror insert for OD-EF turning </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-danger">REJECTED</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>

							
							<td>
							<center>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-twitter" onclick="window.location.href='IN0008.php';"><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-success" data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>			
                           <div class="modal fade" id="approveModal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog" role="document">
								<div class="modal-content">
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center">Would you like to approve?</h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
									  <div class="form-group">
										<textarea class="form-control" id="approveTextarea1" rows="6"></textarea>
									  </div>
									</form>
								  </div>
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-success btn-fw" >YES</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
								  </div>
								  </div>
								</div>
								</div>
							<button type="button" class="badge btn btn-sm btn-social-icon btn-warning" onclick="window.location.href='IN0004.php';" ><i class ="mdi mdi-clipboard-outline"></i></button>
							
							
							
							
							</center>
							
							  </div>
							
							</td>
                          </tr>
                        </tbody>.
                      </table>
                 </div>
				   </form>
                  </div>
                </div>
              </div>
                  <!--</div>
                </div>
              </div>-->
		

              </div>
            </div>
	</div>

	</div>	
	

  </body>
</html>