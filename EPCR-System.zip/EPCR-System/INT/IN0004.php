	
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    <!-- plugins:css -->
    <link rel="stylesheet" href="../../../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../../../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link rel="stylesheet" href="../../../assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../../../assets/css/demo_1/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../../../assets/images/favicon.png">
  </head>













  <body>
  <div class="container-scroller">
    <!------------------------------------------------ Header templete ------------------------------------------------>
	<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="IN0000.php"><h1><b>E-PCR</b><h1></a>
         <a class="navbar-brand brand-logo-mini" href="IN0000.php"><img src="../assets/images/gears.svg" alt="logo" style=" width: 50%; height: 50%; "/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../assets/images/settings.svg" alt="image">
                  <span class="availability-status online"></span>
                </div>
              <div class="nav-profile-text">
				<span class="menu-title"><b>Setting</b></span>
                </div> 
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="Setting_password.php">
                   <i class="mdi mdi-cached mr-2 text-success" href="IN0000.php"></i> Change Password
				 </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout mr-2 text-primary"></i> Signout 
				</a>
              </div>
            </li> 
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
    </nav>
  
  <!------------------------------------------------ Header templete ------------------------------------------------>
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_user.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
			
		  			<!--space header-->
			
			    
					  <div class="card">
			 <div class="card-header headC">
    <center style="color:white;"><h5><b>PCR form</b><h5></center>
	 
  </div>
			    <div class="row">

                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">

                                    <form class="form-sample">
                                        <table class="tg" width="100%">
                                            <tr>
                                                <td class="tg-0lax" colspan="2" style="text-align: right;">
                                                    <b>Crated Date:</b> 22/07/2020
                                                </td>
                                            </tr>

                                            <tr>
                                                <td><b>Department / Section:</b> Production Engineer
                                                </td>
                                                <td><b>Registant:</b> MS.Kittiya Yangsao
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>PCR No:</b> DN-PCR-FY20-001</td>
                                            </tr>
                                            <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
                                            <tr>
										</table>
										  <table class="tg" width="100%">
                                            <tr >
                                                <td class="tg-0lax" colspan="2" style="text-align: right;"><b>PCR Type:</b> Normal</td>
                                            </tr>
                                            <tr>
                                                <td><b>Additon</b> item: No
                                                </td>
                                                <td><b>Annual Plan no:</b> DN-FY20-001
                                                </td>
												
                                            </tr>
                                            <tr>
                                                <td><b> Change type:</b> Repeat
                                                </td>
                                                <td><b>Rank:</b> C2
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Customer submission:</b> Nissan
                                                </td>
                                                <td><b>Planning review:</b> Yes
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Product:</b> G3S
                                                </td>
                                                <td><b>Part name:</b> INJ Inspection
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Part number:</b> SDM-444555555
                                                </td>
                                                <td><b>Change point:</b> Modify manchine
                                                </td>
                                            </tr>
											  <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											</table>
											
											 <table class="tg" width="100%"  >
                                            <tr>
                                                <td><u><b>Priority Management category:</b></u>
                                                </td>

                                            </tr>
											<tr>
											<td>
					<div class="row">
						<div class="col-md-2">
                          <div class="form-group">
						   <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" checked disabled  class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/S2-removebg.png" class="imageC2" >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" checked disabled  class="form-check-input"></label>
								<img src="../assets/images/simbol/S3-removebg.png" class="imageC2" >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" disabled class="form-check-input" >  </label>
								<img src="../assets/images/simbol/S1-removebg.png" class="imageC2" >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                           <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" disabled class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/F2-removebg.png" class="imageC2" >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" checked disabled class="form-check-input"></label>
								<img src="../assets/images/simbol/F3-removebg.png" class="imageC2" >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" disabled class="form-check-input" >  </label>
								<img src="../assets/images/simbol/F1-removebg.png" class="imageC2" >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/E2-removebg.png" class="imageC2">
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/E3-removebg.png" class="imageC2"  >
                            </div>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input  disabled type="checkbox" checked class="form-check-input" >  </label>
								<img src="../assets/images/simbol/E1-removebg.png" class="imageC2"  >
                            </div>
                            
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input type="checkbox" checked disabled class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/C2-removebg.png" class="imageC2"  >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/C3-removebg.png" class="imageC2"  >
                            </div>  
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" checked class="form-check-input"></label>
								<img src="../assets/images/simbol/C4-removebg-preview.png" class="imageC2"  >
                            </div> 							
                          </div>
                        </div>
						<div class="col-md-2">
                          <div class="form-group">
						  <label></label>
                            <div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" class="form-check-input">  
								</label>
								<img src="../assets/images/simbol/DK-removebg-preview.png" class="imageC2"  >
                            </div>
							<div class="form-check col-sm-6">
                              <label class="form-check-label">
                                <input disabled type="checkbox" class="form-check-input"></label>
								<img src="../assets/images/simbol/In-removebg-preview.png" class="imageC2"  >
                            </div>  
														
                          </div>
                        </div>
						
                      </div>
								         </td>
								           </tr>
											</table>
                                           
											
                                           
                                            <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											</table>
											 <table class="tg" width="100%"  >
                                            <tr>
                                                <td><u><b>Detail of process change</b></u>
                                                </td>

                                            </tr>
                                            <tr>
                                                <td><center><u>Plan</u> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<u>Result</u></center>
                                                </td>

                                            </tr>
                                            <tr><center>
                                                <td colspan="3">
                                                    <center><img src="https://www.pngitem.com/pimgs/m/499-4997293_pdf-file-icon-png-transparent-png.png" style="width:48px;height:48px;text-align: center;"> &emsp;&emsp;&emsp;&emsp;&emsp;
                                                    <img src="https://www.pngitem.com/pimgs/m/499-4997293_pdf-file-icon-png-transparent-png.png" style="width:48px;height:48px;text-align: center;"><center>
                                                </td></center>
                                            </tr>
                                            <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											</table>
											 <table class="tg" width="100%">
                                            <tr>
                                                <td><u><b>Implementtion Plan</b></u></td>

                                            </tr>
                                             <tr>
                                                <td width = "50%">1) PCR plan submission
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width = "50%">2) Planing review
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width = "50%">3) Process preparation
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                           <tr>
                                                <td width = "50%">4) Process evaluation
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                           <tr>
                                                <td width = "50%">5) PCR plan submission
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                           <tr>
                                                <td width = "50%">6) Revise document standard
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                        <tr>
                                                <td width = "50%">7) 6 step / Quality report
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                            </tr>
                                           <tr>
                                                <td width = "50%">8) PCR result submission
                                                </td>
                                                <td><b>Plan: </b> 22/06/62
                                                </td>
												<td><b>Actual:</b> 22/06/62
                                                </td>
                                           
											</table>	                             
											<table class="tg" width="100%" >
											
											    <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
                                            <tr heigth="300">
                                                <td><u><b>Data attachments:</b></u></td>
												
                                            </tr>
											<tr>
										
                                                <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input" checked > 1.PFMEA 
												</td>
												<td>
												<u>Document No:</u> <b style ="color : #55bdce">123</b>
												</td>
												<td>
											
												</td>
											
                                            </tr>
											<tr>
                                                <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled  type="checkbox" class="form-check-input" checked > 2.QA Network 
												</td>
												<td>
												<u>Document No:</u> <b style ="color : #55bdce">768</b>
												</td>											
                                            </tr>
											
											<tr>
                                                <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled  type="checkbox" class="form-check-input" checked > 3.Control plan ,PCC 
												</td>
												<td>
												<u>Document No:</u> <b style ="color : #55bdce">223</b>
												</td>
											
                                            </tr>
											<tr>
                                               
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled  type="checkbox" class="form-check-input" checked > 4.Standardize work , WI
												</td>	
												<td>
												<u>Document No:</u> <b style ="color : #55bdce">23</b>
												</td>												
                                            </tr>
											<tr>
                                               
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input  disabled  type="checkbox" class="form-check-input"  > 5.Machine specification (Change point of machine)
												</td>											
                                            </tr>
											<tr>
                                               <tr>
                                               
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input  disabled  type="checkbox" class="form-check-input" checked > 6.Daily check sheet of machine
												</td>											
                                            </tr>
											<tr>
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled  type="checkbox" class="form-check-input"  > 7.Other
												</td>											
                                            </tr>
											
											    <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											
                                        </table>
										 
                                        <table class="tg" width="100%" >
										
										<tr>
                                                <td class="badge badge-success"><b>Approval plan</u> 
                                                </td>
											
                                            </tr>
											
											<tr>
											
											
                                                <td style="color:#0489B1"><b>Approve of department:</b>
                                                </td>
											
                                            </tr>
											
											<tr>
                                                <td><b>Checker 1</b>: MS.Okamase Yang
                                                </td>
											 <td><b>Position:</b> AM</td>
                                                </tr>
                                                <tr>
												 </td>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
											<tr>
                                                <td><b>Approver:</b> MS.Huikami Tong
                                                </td>
											 <td><b>Position:</b> AD
                                                </td>
												 </tr>
                                                 <tr>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
											</table>
											<table class="tg" width="100%" >
											<tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											<tr>
											
                                                <td style="color:#0489B1"><b>Ackowleage department:</b> 
                                                </td>
											
                                            </tr>
											<tr>
                                                <td><b>Approver 1:</b> MR.Samanya Sukya
                                                </td>
											 <td><b>Position:</b> Am
                                                </td>
                                                </tr>
                                                <tr>
												<td><b>Comments:</b>  -
                                                </td>
                                            </tr>
											<tr>
                                                <td><b>Approver 2:</b> MS.Huikami Tong
                                                </td>
											 <td><b>Position</b>: Mgr
                                                </td>
                                                </tr>
                                                <tr>
												 </td>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
											<tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											</table>
											<table class="tg" width="100%" >
											<tr>
                                                <td  style="color:#0489B1"><b>QAP Approve:</b>
                                                </td>
											
                                            </tr>											
						                     <tr>
											 
                                                <td>
												<b><u>Planning review meeting</u></b> 
                                                </td>
											 
                                            </tr>
											<tr>
                                                <td>
												<b>Chairman:</b> Kittiya Eikitai 
                                                </td>
											 
                                            </tr>

											<tr>
                                                <td>
												<b>Comments:</b> -
                                                </td>
											 
                                            </tr>
											<tr>
										 <td><b>6 Step meeting<b></td>
										 </tr>
										 <tr>

                                                <td >
												
												&emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input" disabled > Part Examination
												</td>									
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input"  disabled> Process Explanation
												</td>
												<td>
											    &emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input"disabled > Process Examination

												</td>
                                            </tr>
											 <tr>
										        
                                                <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input"  disabled> Total  Review
												</td>									
												 <td>
												&emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input" disabled> Shipment Review
												</td>
												<td>
											    &emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input"  disabled> QA Meeting

												</td>
                                            </tr>
											
											<tr>
                                            <td style="color:#0489B1">
											 &emsp;&emsp;&emsp;&emsp;<input disabled type="checkbox" class="form-check-input" disabled > <b>Quality Report</b>
											</td>
											</tr>
											<tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											<tr>
											</table>
											<table class="tg" width="100%" >
                                           <tr>
                                                <td  style="color:#0489B1"><b>BKD Approve:</b>
                                                </td>
											
                                            </tr>
											<tr>
                                                <td>
												<b>BKD Check:</b> Require.
                                                </td>
											 
                                            </tr>
											<tr>
                                                <td>
												<b>Comments:</b> -
                                                </td>
											 
                                            </tr>
											 <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
                                           
                                             </table>
											 <table class="tg" width="100%" >
                                                <td style="color:#0489B1"><b>Concern department:</b> 
                                                </td>											
                                            </tr>
											<tr>
											
                                                <td><u><b>Department:</b> Production</u>
                                                </td>										
                                            </tr>	
											<tr>
                                                <td>1: MS.Kaosue Pongsako
                                                </td>
											 <td><b>Position</b>: Staff
                                                </td>
												</tr>
                                                
                                            <tr>
                                                <td>2: MR.Linda Opmtita
                                                </td>
											 <td><b>Position:</b> Sr.staff
                                                </td>
												 </tr>
                                                 
                                            <tr>
                                                <td>3: MS.Ponpilin
                                                </td>
											 <td><b>Position:</b> Sr.staff
                                                </td>
                                                </tr>
                                                <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											
										 </table>
										<table class="tg" width="100%" >
										
										<tr>
                                                <td class="badge badge-info"><b>Approval result</b></u> 
                                                </td>
											
                                            </tr>
											
											<tr>
											
											
                                                <td style="color:#0489B1"><b>Approve of department:</b>
                                                </td>
											
                                            </tr>
											
											<tr>
                                                <td><b>Checker 1</b>: MS.Okamase Yang
                                                </td>
											 <td><b>Position:</b> AM</td>
                                                </tr>
                                                <tr>
												 </td>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
											<tr>
                                                <td><b>Approver:</b> MS.Huikami Tong
                                                </td>
											 <td><b>Position:</b> AD
                                                </td>
												 </tr>
                                                 <tr>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
											</table>
											<table class="tg" width="100%" >
											<tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											<tr>
											
                                                <td style="color:#0489B1"><b>Ackowleage department:</b> 
                                                </td>
											
                                            </tr>
											<tr>
                                                <td><b>Approver 1:</b> MR.Samanya Sukya
                                                </td>
											 <td><b>Position:</b> Am
                                                </td>
                                                </tr>
                                                <tr>
												<td><b>Comments:</b>  -
                                                </td>
                                            </tr>
											<tr>
                                                <td><b>Approver 2:</b> MS.Huikami Tong
                                                </td>
											 <td><b>Position</b>: Mgr
                                                </td>
                                                </tr>
                                                <tr>
												 </td>
												<td><b>Comments:</b> -
                                                </td>
                                            </tr>
										<tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											</table>
											<table class="tg" width="100%" >
                                                <td style="color:#0489B1"><b>Concern department:</b> 
                                                </td>											
                                            </tr>
											<tr>
											
                                                <td><u><b>Department:</b> Production</u>
                                                </td>										
                                            </tr>	
											<tr>
                                                <td>1: MS.Kaosue Pongsako
                                                </td>
											 <td><b>Position</b>: Staff
                                                </td>
												</tr>
                                                
                                            <tr>
                                                <td>2: MR.Linda Opmtita
                                                </td>
											 <td><b>Position:</b> Sr.staff
                                                </td>
												 </tr>
                                                 
                                            <tr>
                                                <td>3: MS.Ponpilin
                                                </td>
											 <td><b>Position:</b> Sr.staff
                                                </td>
                                                </tr>
                                                <tr style="height: 0px">
                                                <td colspan="2">
                                                    <hr>
                                                </td>
                                            </tr>
											
										 </table>
                                        
										 <button style ="background-color:#7eb73d; border-color:#7eb73d;" type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">Approve</button>
										 <button style ="background-color:#c2161c ; border-color:#c2161c ;"type="button" class="btn btn-secondary" data-toggle="modal" data-target="#mydelete" >Not Approve</button>
										 
										
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>


   
	
               
<!---->
              </div>

			
			
	
			

			
			
				
	
               
		

              </div>
            </div>
			
	</div>

	</div>	
	   
  </body>


  <style type="text/css">
                            .tg {
                                border: 0;
                                border-spacing: 0;
                            }
                            
                            .tg td {
                                font-family: Arial, sans-serif;
                                font-size: 14px;
                                padding: 10px 5px;
                            }
                            
                            .tg th {
                                font-family: Arial, sans-serif;
                                font-size: 14px;
                                font-weight: normal;
                                padding: 10px 5px;
                            }
                            
                            .tg .tg-0lax {
                                text-align: left;
                                vertical-align: top;
                            }
                            
                            .header-text {
                                text-align: center !important;
                                font-size: 25px;
                            }
                            
                            li {
                                padding-bottom: 10px !important;
                            }
.headC{
	background-color: #b66dff;
	height: 35px;
}
button.C{
      width : 25%;	
	  height : 25px;
}
button.navbtn{
  position: absolute;
  top:50%;
  right: 0;
  width: 100px;
  height : 35px;
  transform: translateY(-50%);
	
}
</style>
<!-- Modal HTML -->
<!--confirm button-->
<div id="mydelete" class="modal fade">
	<div class="modal-dialog modal-confirm">
		<div class="modal-content">
			<div class="modal-header flex-column">
									
				<h3 class="modal-title">Are you sure to not approve?</h3>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
			<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
			</div>
			<div class="modal-footer justify-content-center">
      <button style ="background-color:#7eb73d; border-color:#7eb73d;" type="button" class="btn btn-danger">Submit</button>
				<button style ="background-color:#686868 ; border-color:#686868 ;"type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
			</div>
		</div>
	</div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-confirm" >
    <div class="modal-content">
		<div class="modal-header flex-column">						
		<h3 class="modal-title w-100">Are you sure to not approve?</h3>	
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		</div>
		<div class="modal-body">
			<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
		</div>
		<div class="modal-footer justify-content-center">
			<button style ="background-color:#7eb73d; border-color:#7eb73d;" type="button" class="btn btn-danger">Submit</button>
			<button style ="background-color:#686868 ; border-color:#686868 ;"type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
		</div>			
									
		</div>
  </div>
</div>
<!--confirm button-->
<style>
/*confirm button*/
body {
	font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 400px;
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
/*confirm button*/
</style>
</html>