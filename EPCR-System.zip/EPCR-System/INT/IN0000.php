<!DOCTYPE html>
<html lang="en">
	
  <body>
  <div class="container-scroller">
    <!------------------------------------------------ Header templete ------------------------------------------------>
	<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="IN0000.php"><h1><b>E-PCR</b><h1></a>
         <a class="navbar-brand brand-logo-mini" href="IN0000.php"><img src="../assets/images/gears.svg" alt="logo" style=" width: 50%; height: 50%; "/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../assets/images/settings.svg" alt="image">
                  <span class="availability-status online"></span>
                </div>
              <div class="nav-profile-text">
				<span class="menu-title"><b>Setting</b></span>
                </div> 
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="Setting_password.php">
                   <i class="mdi mdi-cached mr-2 text-success" href="IN0000.php"></i> Change Password
				 </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout mr-2 text-primary"></i> Signout 
				</a>
              </div>
            </li> 
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
    </nav>
  
  <!------------------------------------------------ Header templete ------------------------------------------------>
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_user.php")?>
		
	    <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
			
			
			<div class="col-12 grid-margin stretch-card">
                <div class="card">
				
                  <div class="card-body">
                    <h4 class="card-title">Process Change Report</h4>
                    <p class="card-description"> Table of Process </p>
                    <form class="forms-sample">
                    <div class="table-responsive">
                      <table id="example" class="table table-striped table-bordered dt-responsive nowrap" style="width:100%">
                         <thead class="thead-dark">
                          <tr>
							<th><center> No </center></th>
							<th><center> Date </center></th>
                            <th><center> Product name </center></th>
                            <th><center> Title</center> </th>
                            <th><center> Rank </center></th>
                            <th> <center>Customer submission </center></th>
							<th> <center>Status </center> </th>	
                            <th> <center>PIC </center></th>
							 <th><center> Leadtime </center></th>					
							   <th><center> Action </center> </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
						  <td> <center>1</center></td>
						  <td>01/07/2020</td>
                            <td> HP5S</td>
                            <td> New G4S Body pre washing machine </td>
                            <td>
                              C1
                            </td>
                            <td> All</td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>						
							<td>
								<center>
									<button type="button" class="badge btn-warning small-btn " ><i class ="mdi mdi-magnify"></i></button>
									<button type="button" class="badge  btn-success small-btn"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>
									<button type="button" class="badge btn-dark small-btn nav-link" onclick="window.location.href='IN0015.php';"><i class ="mdi mdi-clipboard-outline"></i></button>
									<button type="button" class="badge btn-danger small-btn" data-toggle="modal" data-target="#Upload_DAR_Modal"><i class ="mdi mdi-delete-forever  " ></i></button>
								</center>
							</td>
                          </tr>
                          <tr>
						  <td> <center>2 </center></td>
						  <td>05/05/2020</td>
                            <td>HP3 </td>
                            <td> Improvement process flow </td>
                            <td>
                              C3
                            </td>
							
                            <td> All </td>
							<td><label class="badge badge-gradient-warning">ON PLAN</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>
							
							<td>
							<center><button type="button" class="badge btn-warning small-btn " ><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge  btn-success small-btn"><i class ="mdi mdi-checkbox-multiple-marked-circle "></i></button>
							<button type="button" class="badge btn-dark small-btn"><i class ="mdi mdi-clipboard-outline"></i></button>
							<button type="button" class="badge btn-danger small-btn" data-toggle="modal" data-target="#Upload_DAR_Modal"><i class ="mdi mdi-delete-forever"></i></button></center>
							</td>
                          </tr>
                          <tr>
						  <td>  <center>3 </center></td>
						  <td>01/03/2020</td>
                            <td>INJ</td>
                            <td> Tool cost down by change </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-success">COMPLETE</label></td>
                            <td> Rattapong Y. </td>
							<td> Normal </td>

							<td>
							<center><button type="button" class="badge btn-warning small-btn " ><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge  btn-success small-btn"><i class ="mdi mdi-checkbox-multiple-marked-circle "></i></button>
							<button type="button" class="badge btn-dark small-btn"><i class ="mdi mdi-clipboard-outline"></i></button>
							<button type="button" class="badge btn-danger small-btn" data-toggle="modal" data-target="#Upload_DAR_Modal" ><i class ="mdi mdi-delete-forever "></i></button></center>
							</td>
							
                          </tr>
                          <tr>
						  <td> <center> 4  </center></td>
						  	<td>01/02/2019</td>
                            <td>Pump </td>
                            <td> Mirror insert for OD-EF turning </td>
                            <td>
                              C2
                            </td>
                            <td> All </td>
							<td> <label class="badge badge-gradient-danger">REJECTED</label></td>
                            <td> Rattapong Y.</td>
							<td> Normal </td>

							
							<td>
							<center><button type="button" class="badge btn-warning small-btn " ><i class ="mdi mdi-magnify"></i></button>
							<button type="button" class="badge  btn-success small-btn"><i class ="mdi mdi-checkbox-multiple-marked-circle "></i></button>
							<button type="button" class="badge btn-dark small-btn"><i class ="mdi mdi-clipboard-outline"></i></button>
							<button type="button" class="badge btn-danger small-btn" data-toggle="modal" data-target="#Upload_DAR_Modal"><i class ="mdi mdi-delete-forever"></i></button></center>
							</td>
                          </tr>
                        </tbody>.
                      </table>
                 </div>
				   </form>
                  </div>
                </div>
              </div>
                  <!--</div>
                </div>
              </div>-->
			  
            </div>

              </div>
            </div>
	</div>

	</div>	
		
		<!-- endinject -->
		<!-- Plugin js for this page -->
		<!-- End plugin js for this page -->
		<!-- inject:js -->
		<script src="../assets/js/form.js"></script>
		<script src="../assets/js/datepicker.js"></script>
		<script src="../assets/js/file-upload.js"></script>
		<script src="../assets/js/off-canvas.js"></script>
		<script src="../assets/js/hoverable-collapse.js"></script>
		<script src="../assets/js/misc.js"></script>
		<!-- endinject -->
	
		<!-- endinject -->
  </body>
</html>



 <div class="modal fade" id="Upload_DAR_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
						<center>
							
						</center>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
			    </div>
			<div class="modal-body">
					
				<div class="card">
								<h3 class="page-title-icon bg-gradient-primary" style="background-color:#b66dff;text-align: center;">
											<b class= "text-white">Upload file DAR</b> 
								</h3>
					<div class="card-body"> 
									<form class="form-sample"> <!-- Form input BKD-->  
									
									<div class="form-group">
										<label>No.PCR</label>
										<!--<h4 class="card-title">No.PCR</h4>-->
										<input class="form-control" id="" type="text" name="" />
									</div>
										<br>
									<!--  <div class="row">
										<div class="col-md-12">
										  <div class="form-group row">
										   <label class="col-sm-5 col-form-label">BKD Check</label>-->
										<!--	<div class="col-sm-6">
												  xdfsdsf
											</div>
											<div class="col-sm-6">
												  dsdfsdf
											</div>
										  </div>
										 </div>
										</div>-->
									<div class="form-group">
										<!--<label for="exampleTextarea1">More request</label>
										<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>-->
										
										<label>File upload DAR</label>
											<input type="file" name="img[]" class="file-upload-default">
										<div class="input-group col-xs-12">
											<input type="text" class="form-control file-upload-info" disabled placeholder="Upload Image">
												<span class="input-group-append">
													<button class="file-upload-browse btn btn-gradient-primary" type="button" 
													style="backgroundr:#ffffff;">Upload
													</button>
												</span>
										</div>
										
									</div>          
									</form>
									
						</div>
					</div>
									
					
			</div>
				<div class="modal-footer justify-content-between">
						<button type="submit" class="btn btn-success btn-fw"  data-dismiss="modal">YES</button>
						<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
				</div>
			  </div>
		</div>
	</div>