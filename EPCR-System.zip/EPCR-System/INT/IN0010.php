	
<!DOCTYPE html>
<html lang="en">

	<head>
	   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>


  <!-- Fonts and icons -->
  <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
   
  </head>

	
  <body>
	  <script>
	  $(document).ready(function() {
		$('#example').DataTable();
	} );
	  </script>
 
  <div class="container-scroller">
  <!------------------------------------------------ Header templete ------------------------------------------------>
	<nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
        <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
          <a class="navbar-brand brand-logo" href="IN0000.php"><h1><b>E-PCR</b><h1></a>
         <a class="navbar-brand brand-logo-mini" href="IN0000.php"><img src="../assets/images/gears.svg" alt="logo" style=" width: 50%; height: 50%; "/></a>
        </div>
        <div class="navbar-menu-wrapper d-flex align-items-stretch">
          <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="mdi mdi-menu"></span>
          </button>
          <div class="search-field d-none d-md-block">
            <form class="d-flex align-items-center h-100" action="#">
              <div class="input-group">
                <div class="input-group-prepend bg-transparent">
                  <i class="input-group-text border-0 mdi mdi-magnify"></i>
                </div>
                <input type="text" class="form-control bg-transparent border-0" placeholder="Search projects">
              </div>
            </form>
          </div>
          <ul class="navbar-nav navbar-nav-right">
            <li class="nav-item nav-profile dropdown">
              <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                <div class="nav-profile-img">
                  <img src="../assets/images/settings.svg" alt="image">
                  <span class="availability-status online"></span>
                </div>
              <div class="nav-profile-text">
				<span class="menu-title"><b>Setting</b></span>
                </div> 
              </a>
              <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
                <a class="dropdown-item" href="Setting_password.php">
                   <i class="mdi mdi-cached mr-2 text-success" href="IN0000.php"></i> Change Password
				 </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">
                  <i class="mdi mdi-logout mr-2 text-primary"></i> Signout 
				</a>
              </div>
            </li> 
          </ul>
          <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
            <span class="mdi mdi-menu"></span>
          </button>
        </div>
    </nav>
  
  <!------------------------------------------------ Header templete ------------------------------------------------>
	<div class="container-fluid page-body-wrapper">
	<?php
    include("header_QAP.php")?>
		<!--space header-->
	    <div class="main-panel">
          <div class="content-wrapper">
            
			
			  <div class="card-header headC">
				<center style="color:white;"><h4><b>QAP Approval</b><h4></center>
			  </div>
				<div class="card">
					<form class="forms-sample">
						<div class="data-table-area">
						<!---->
						
							<div class="card-body">
							  <div class="table-responsive">
							  <table id="example" class="table table-hover ">
							  <thead>
							  
								<tr>
								  <th><center>No</center></th>
								  <th><center>Product name</center></th>
								  <th><center>Title</center></th>
								  <th><center>Rank</center></th>
								  <th><center>Customer submission</center></th>
								  <th><center>PIC</center></th>
								  <th><center>PCR Type</center></th>
								  <th><center>Status</center></th>
								  <th><center>Date</center></th>
								  <th><center>Action</center></th>
								</tr>
							  </thead>
							  <tbody>
								<tr>
								  <td> <center>1</center></td>
									<td><center> HP5S</center></td>
									<td><center>New G4S Body pre washing machine </center></td>
									<td><center>C1</center></td>
									<td><center>All</center></td>
									<td><label><center>COMPLETE</center></label></td>
									<td><center>Rattapong Y.</center></td>
									<td><center>Normal </center></td>
									<td><center>05/05/2020</center></td>
								 <center>
									 <td>
										 <center>
											 <button style ="background-color:#00bcd4; border-color:#fff;" type="button" class="btn btn-sm btn-info"data-toggle="modal" data-target="#myApprove" data-whatever="@mdo">
												 <img src="../assets/images/button/search.png" class = "icon"/>
											 </button>
											 <button type="button"style ="background-color:#5b5b5b; border-color:#fff;" class="btn btn-sm btn-danger"data-toggle="modal" data-target="#myApprove" data-whatever="@mdo">
												 <img src="../assets/images/button/status-button.png" class = "icon" />
											 </button>
										 </center>
									 </td>
								 </center>
								</tr>
								<tr>
								  <td> <center>2 </center></td> 	
									<td><center>HP3</center> </td>
									<td><center>Improvement process flow</center> </td>
									<td><center>C3</center></td>
									<td><center>All</center> </td>
									<td><label></center>ON PLAN<center></label></td>
									<td><center>Rattapong Y.</center></td>
									<td><center> Normal </center></td>	
									<td><center>05/05/2020</center></td>		
								  <center><td><center><button style ="background-color:#00bcd4; border-color:#fff;" type="button" class="btn btn-sm btn-info"data-toggle="modal" data-target="#myApprove">
								 <img src="../assets/images/button/search.png" class = "icon"/></button>
								 <button type="button"style ="background-color:#5b5b5b; border-color:#fff;" class="btn btn-sm btn-danger"data-toggle="modal" data-target="#mydelete"><img src="../assets/images/button/status-button.png" class = "icon" /></button></center></td></center>
								</tr>
				
								
								
							  </tbody>
							</table>													
							</div>
						  </div>
			
					</div>
				</form>
			
		
				
	
               
		
<!---------------------------------------------------------------------------------------------------------------->
              </div>
            </div>
			
	</div>

	</div>	
</div>
  </body>
  
  <style>
  .tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}

  
  
.headC{
	background-color: #b66dff;
	height: 45px;
}
button.one {
	background-color: #4CAF50;
	font-size: 10px;
	}
.icon{
	max-height: 15px;
	max-width: 15px;
	width: 15px;
	height: 15px;
	}
	
	body {
	font-family: 'Varela Round', sans-serif;
}
.modal-confirm {		
	color: #636363;
	width: 400px;
}
.modal-confirm .modal-content {
	padding: 20px;
	border-radius: 5px;
	border: none;
	text-align: center;
	font-size: 14px;
}
.modal-confirm .modal-header {
	border-bottom: none;   
	position: relative;
}
.modal-confirm h4 {
	text-align: center;
	font-size: 26px;
	margin: 30px 0 -10px;
}
.modal-confirm .close {
	position: absolute;
	top: -5px;
	right: -2px;
}
.modal-confirm .modal-body {
	color: #999;
}
.modal-confirm .modal-footer {
	border: none;
	text-align: center;		
	border-radius: 5px;
	font-size: 13px;
	padding: 10px 15px 25px;
}
.modal-confirm .modal-footer a {
	color: #999;
}		
.modal-confirm .icon-box {
	width: 80px;
	height: 80px;
	margin: 0 auto;
	border-radius: 50%;
	z-index: 9;
	text-align: center;
	border: 3px solid #f15e5e;
}
.modal-confirm .icon-box i {
	color: #f15e5e;
	font-size: 46px;
	display: inline-block;
	margin-top: 13px;
}
.modal-confirm .btn, .modal-confirm .btn:active {
	color: #fff;
	border-radius: 4px;
	background: #60c7c1;
	text-decoration: none;
	transition: all 0.4s;
	line-height: normal;
	min-width: 120px;
	border: none;
	min-height: 40px;
	border-radius: 3px;
	margin: 0 5px;
}
.modal-confirm .btn-secondary {
	background: #c1c1c1;
}
.modal-confirm .btn-secondary:hover, .modal-confirm .btn-secondary:focus {
	background: #a8a8a8;
}
.modal-confirm .btn-danger {
	background: #f15e5e;
}
.modal-confirm .btn-danger:hover, .modal-confirm .btn-danger:focus {
	background: #ee3535;
}
.trigger-btn {
	display: inline-block;
	margin: 100px auto;
}
</style>



<!--Data table -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/bootstrap-table/dist/bootstrap-table.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>



<div id="myApprove" class="modal fade">
	<div class="modal-dialog modal-confirm">
		<div class="modal-content">
			<div class="modal-header flex-column">
									
				<h4 class="modal-title w-100">Are you sure to Approve?</h4>	
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<p>Do you really want to approve these user? </p>
			</div>
			<div class="modal-footer justify-content-center">
				<button type="button" class="btn btn-danger">Yes</button>
				<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
			</div>
		</div>
	</div>
</div>


<!-- Modal HTML -->
<!--confirm button-->
				<!--<div id="approveModal" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
							  <div class="modal-dialog">
								<div class="modal-content">
						
								  <div class="modal-header">
									<center>
									<h3 class="modal-title" id="approveModalLabel" style= "text-align:center"></h3>
									</center>
									<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									  <span aria-hidden="true">&times;</span>
									</button>
								  </div>
								  <div class="modal-body">
									<form>
										<div class="card">
											<h3 class="page-title-icon bg-gradient-primary " style="background-color:#b66dff;text-align:center">
												<b class="text-white">QAP Approval</b> 
											</h3>
											<div class="card-body">
												  <form class="card-header">
												  <div><b>Planning review meeting</b></div><br>
													  <div>
														<label>Chairman</label>
														<div>
														  <input type="text" class="form-control" />
														</div>
													  </div>
													  &nbsp;
														<div class="form-group">
														<label for="exampleTextarea1">Comment</label>
														<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
													  </div>          
													</form>
													<div><b>6 Step meeting</b></div><br>
													
													<div class="row">
														<div class="col-md-6">
														  <div class="form-group">
														  <div class=>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">  
																Part Examination
																</label>
															</div>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">
																Process Examination
															  </label>
																
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input" >  
																Shipment Review
																</label>
															</div>
															
														  </div>
														</div>
														<div class="col-md-6">
														   <div class="form-group">
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input"> 
																Process Explanationd
																</label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input">
																Total  Review
																</label>
															</div>
															<div class="form-check">
															  <label class="form-check-label">
																<input type="checkbox" class="form-check-input"> 
																QA Meeting
																</label>
															</div>
															
														  </div>
														</div>
													  </div>
													  <div><b>1 Step no meeting</b></div><br>
													<div class="row">
														<div class="col-md-6">
													   <div class="form-group">
														<div class="form-check">
														  <label class="form-check-label">
															<input type="checkbox" class="form-check-input"> 
															QA Report
															</label>
														</div>
													  </div>
													</div>
												  </div>
												
											</div>		
										</div>
									</form>
								 
								  <div class="modal-footer justify-content-between">
									<button type="submit" class="btn btn-primary btn-fw" >Submit</button>
									<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">Cancel</button>
								  </div>
								  </div>
								</div>
								</div>
								</div>-->

  
</html>