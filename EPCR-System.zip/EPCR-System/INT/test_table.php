	
<!DOCTYPE html>
<html lang="en">

	<head>
	
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
	   <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

	
	  <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet" />
  <link href="assets/css/fresh-bootstrap-table.css" rel="stylesheet" />

  <!-- Fonts and icons -->
  <link href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" rel="stylesheet">
  <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300" rel="stylesheet" type="text/css">


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/demo_1/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png">
  </head>

	
  <body>
  <script>
  $(document).ready(function() {
    $('#example').DataTable();
} );
  </script>
 
  <div class="container-scroller">
	<div class="container-fluid page-body-wrapper">
	<?php
	include("header_PE_admin.php")?>
		<!--space header-->
	    <div class="main-panel">
          <div class="content-wrapper">
             
			 <li class="nav-item sidebar-actions">
              <span class="nav-link">  
			
                </a>
              </span>
			  
            </li>
			 
			 <li class="nav-item sidebar-actions">
              <span class="nav-link">  
			
                </a>
              </span>
			  
            </li>
			 
			 <li class="nav-item sidebar-actions">
              <span class="nav-link">  
			
                </a>
              </span>
			  
            </li>
			<!--space header-->
			
			  <div class="card-header headC">
    <center style="color:white;"><h4><b>Add User</b><h4></center>
  </div>
			 <div class="card">
			
    <div class="card-body">
			
			   <form class="forms-sample">
			       <div class="data-table-area">
			<!---->
			
			<table id="myTable" class="table hover">
    <thead>
      <th data-field="no"><center><b>No</b></center></th>
	    <th data-field="date"><center><b>Date</b></center></th> 
      <th data-field="name"><center><b>name</b></center></th>
      <th data-field="position"><center><b>Position</b></center></th>
      <th data-field="department"><center><b>Department</b></center></th>  
      <th><center><b>Actions</b></center></th>
    </thead>
    <tbody>
      <tr>
        <td><center>1</center></td>
		 <td><center>12/04/2020</td>
        <td><center>Dakota D.</center></td>
        <td><center>Staff</center></td>
        <td><center>PD</center></td>
       
		<td>
		
		<center><button type="button" class="btn btn-info " data-toggle="modal" data-target="#approveModal" data-whatever="@mdo"><i class ="mdi mdi-checkbox-multiple-marked-circle"></i></button>	
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline"></i></button></center>

	   </td>
      </tr>
      <tr>
        <td><center>2</center></td>
		 <td><center>12/04/2020</td>
        <td><center>Minerva H.</center></td>
        <td><center>Staff</center></td>
        <td><center>PD</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>3</center></td>
		<td><center>07/09/2020</center></td>
        <td><center>Sage R.</center></td>
        <td><center>Staff</center></td>
        <td><center>QA</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>4</center></td>
		 <td><center>07/09/2020</center></td>
        <td><center>Philip C.</center></td>
        <td><center>Staff</center></td>
        <td><center>PE</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>5</center></td>
		 <td><center>06/09/2020</center></td>
        <td><center>Doris G.</center></td>
        <td><center>AM</center></td>
        <td><center>PE</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>6</center></td>
		 <td><center>06/08/2020</center></td>
        <td><center>Mason P.</center></td>
        <td><center>Staff</center></td>
        <td><center>PE</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>7</center></td>
		 <td><center>06/08/2020</center></td>
        <td><center>Alden C.</center></td>
        <td><center>Staff</center></td>
        <td><center>QA</center></td>
       
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>8</center></td>
		 <td><center>23/07/2020</center></td>
        <td><center>Colton H.</center></td>
        <td><center>Staff</center></td>
        <td><center>PE</center></td>
       
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>9</center></td>
		<td><center>20/06/2020</center></td>
        <td><center>Illana N.</center></td>
        <td><center>Staff</center></td>
        <td><center>PD</center></td>
       
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>10</center></td>
		  <td><center>20/04/2020</center></td>
        <td><center>Nicole L.</center></td>
        <td><center>Staff</center></td>
        <td><center>PE</center></td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>11</center></td>
		 <td><center>12/04/2020</center></td>
        <td><center>Chaim S.</center></td>
        <td><center>Staff</center></td>
        <td><center>PE</center></td>
		
       
        <td>
		
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      <tr>
        <td><center>12</td>
		  <td><center>12/04/2020</td>
        <td><center>Josiah S.</td>
        <td><center>Staff</td>
        <td><center>QA</td>
        
        <td>
		<center><button type="button" class="btn btn-info"><i class="mdi mdi-checkbox-marked-circle-outline  "></i></button>
        <button type="button" class="btn btn-danger"><i class="mdi mdi-close-circle-outline  "></i></button></center>
		</td>
      </tr>
      
    </tbody>
	
  </table>
			
</div>
<form>
			
			</div>
				
	
               
		
<!---->
              </div>
            </div>
			
	</div>

	</div>	
	   </div>
  </body>
  
  <style>
.headC{
	background-color: #b66dff;
	height: 35px;
}
button.C{
      width : 25%;	
	  height : 25px;
}
</style>
<!--Data table -->
<script>
$(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>
<div class="modal" id ="approveModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Approve user</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Are you sure to approve?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary">OK</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>
  
</html>