<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="../assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="../assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End Plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="../assets/images/favicon.png" />
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:../../partials/_navbar.html -->
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
	  <?php
	include("header_user.php")?>
		
	  
	  
	  
        <div class="main-panel">
		
          <div class="content-wrapper">
			<div class="col-12">
			<br><br>
			
                <div class="card">
				
				<h3 class="page-title-icon bg-gradient-primary" style="background-color:#b66dff;text-align: center;">
					 <b class= "text-white">DAR Form </b> 
				</h3>
				  
                  <div class="card-body">
				  
                    <h4 class="card-title" style="text-align: center;"><b>Upload file DAR</b></h4>
                 <!--   <form class="form-sample">
                      <p class="card-description"> Input form BKD</p>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group row">
                           <label class="col-sm-3 col-form-label">BKD Check</label>
                            <div class="col-sm-4">
                              <div class="form-check">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Require </label>
                              </div>
                            </div>
                            <div class="col-sm-5">
                              <div class="form-check">
                                <label class="form-check-label">
                                  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Not Require</label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                          <div class="form-group">
                        <label for="exampleTextarea1">More request</label>
                        <textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
                      </div>          
                    </form> -->
					<div class="row">
					 <div class="col-md-6">
					<button class="btn btn-info btn-fw" type="button"data-toggle="modal" data-target="#Approve_BKD_Modal">Submit</button>			
					<!--<button class="btn btn-danger btn-fw" type="button">Cancel</button> -->
					
					</div>
                  </div>
                </div>
              </div>
			
   
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:../../partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2017 <a href="https://www.bootstrapdash.com/" target="_blank">BootstrapDash</a>. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="mdi mdi-heart text-danger"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="../../assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="../../assets/js/off-canvas.js"></script>
    <script src="../../assets/js/hoverable-collapse.js"></script>
    <script src="../../assets/js/misc.js"></script>
    <!-- endinject -->
  </body>
</html>


 <div class="modal fade" id="Approve_BKD_Modal" tabindex="-1" role="dialog" aria-labelledby="approveModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
						<center>
							
						</center>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
			    </div>
				<div class="modal-body">
					
							<div class="card">
								<h3 class="page-title-icon bg-gradient-primary" style=   "background-color:#b66dff;text-align: center;">
											<b class= "text-white">BKD</b> 
								 </h3>
							  <div class="card-body"> 
							  
							  
									<form class="form-sample"> <!-- Form input BKD-->
									  <div class="row">
											<label class="col-sm-5 col-form-label"><b>BKD Check</b></label>
										<div class="col-md-12">
										  <div class="form-group row">
										  <!-- <label class="col-sm-5 col-form-label">BKD Check</label>-->
											<div class="col-sm-6">
												  <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios1" value="" checked> Require </label>
												  </div>
											</div>
											<div class="col-sm-6">
												  <div class="form-check">
														<label class="form-check-label">
														  <input type="radio" class="form-check-input" name="membershipRadios" id="membershipRadios2" value="option2"> Not Require</label>
												  </div>
											</div>
										  </div>
										 </div>
										</div>
										  <div class="form-group">
										<label for="exampleTextarea1">More request</label>
										<textarea class="form-control" id="exampleTextarea1" rows="4"></textarea>
									  </div>          
									</form>
									
								</div>
							  </div>
									
					
					
					
					
					
					
					
					
					
					
					
					
					
				</div>
				<div class="modal-footer justify-content-between">
						<button type="submit" class="btn btn-success btn-fw"  data-dismiss="modal">YES</button>
						<button type="cancel" class="btn btn-light btn-fw" data-dismiss="modal">NO</button>
				</div>
			  </div>
		</div>
	</div>